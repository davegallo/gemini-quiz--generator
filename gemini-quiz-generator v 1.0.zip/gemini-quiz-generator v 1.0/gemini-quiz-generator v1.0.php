<?php
/**
* Plugin Name: Gemini Quiz Generator
* Description: Generates an interactive quiz from page content using the Gemini API. Use the [gemini_quiz] shortcode.
* Version: 1.6.3
* Author: Your Name
* License: GPL-2.0-or-later
* Text Domain: gemini-quiz-generator
*/

// Prevent direct access to the file
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('GEMINI_QUIZ_VERSION', '1.6.3');

/**
 * Initialize the plugin
 */
add_action('init', 'gemini_quiz_init');

function gemini_quiz_init() {
    add_action('rest_api_init', 'gemini_quiz_register_rest_routes');
}

/**
 * Register REST API routes
 */
function gemini_quiz_register_rest_routes() {
    register_rest_route('quiz-generator/v1', '/generate', array(
        'methods' => 'POST',
        'callback' => 'gemini_quiz_generate_quiz',
        'permission_callback' => '__return_true',
        'args' => array(
            'article' => array(
                'required' => true,
                'type' => 'string',
                'sanitize_callback' => 'sanitize_textarea_field',
            ),
            'postId' => array(
                'required' => false,
                'type' => 'integer',
                'sanitize_callback' => 'absint',
            ),
        ),
    ));
}

/**
 * Generate quiz using Gemini API
 */
function gemini_quiz_generate_quiz($request) {
    $article = $request->get_param('article');
    $post_id = $request->get_param('postId');
    
    // Get Gemini API key
    $api_key = defined('GEMINI_API_KEY') ? GEMINI_API_KEY : get_option('gemini_api_key');
    
    if (empty($api_key)) {
        return new WP_Error('missing_api_key', 'Gemini API key is not configured', array('status' => 500));
    }
    
    if (empty($article)) {
        return new WP_Error('empty_article', 'Article content cannot be empty', array('status' => 400));
    }
    
    // Call Gemini API
    $quiz_data = gemini_quiz_call_api($article, $api_key);
    
    if (is_wp_error($quiz_data)) {
        return $quiz_data;
    }
    
    // Get related post if postId is provided
    $related_post = null;
    if ($post_id) {
        $post = get_post($post_id);
        if ($post) {
            $related_post = array(
                'title' => $post->post_title,
                'url' => get_permalink($post->ID),
            );
        }
    }
    
    return array(
        'quiz' => $quiz_data,
        'relatedPost' => $related_post,
    );
}

/**
 * Call Gemini API to generate quiz
 */
function gemini_quiz_call_api($article, $api_key) {
    $prompt = "Based on the following article, create a quiz with 5 multiple-choice questions. Each question should have 4 options with only one correct answer. Return the response as a JSON array where each question object has: 'question' (string), 'options' (array of 4 strings), 'correctAnswer' (integer index 0-3), and 'explanation' (string explaining why the answer is correct).\n\nArticle:\n" . $article;
    
    $body = array(
        'contents' => array(
            array(
                'parts' => array(
                    array('text' => $prompt)
                )
            )
        ),
        'generationConfig' => array(
            'temperature' => 0.7,
            'maxOutputTokens' => 2048,
        )
    );
    
    $response = wp_remote_post("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key=" . $api_key, array(
        'headers' => array(
            'Content-Type' => 'application/json',
        ),
        'body' => json_encode($body),
        'timeout' => 30,
    ));
    
    if (is_wp_error($response)) {
        return new WP_Error('api_error', 'Failed to connect to Gemini API: ' . $response->get_error_message(), array('status' => 500));
    }
    
    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = wp_remote_retrieve_body($response);
    
    if ($response_code !== 200) {
        return new WP_Error('api_error', 'Gemini API returned error: ' . $response_code, array('status' => 500));
    }
    
    $data = json_decode($response_body, true);
    
    if (!$data || !isset($data['candidates'][0]['content']['parts'][0]['text'])) {
        return new WP_Error('invalid_response', 'Invalid response from Gemini API', array('status' => 500));
    }
    
    $quiz_text = $data['candidates'][0]['content']['parts'][0]['text'];
    
    // Extract JSON from the response
    $quiz_text = preg_replace('/```json\s*/', '', $quiz_text);
    $quiz_text = preg_replace('/```\s*$/', '', $quiz_text);
    $quiz_text = trim($quiz_text);
    
    $quiz_data = json_decode($quiz_text, true);
    
    if (!$quiz_data || !is_array($quiz_data)) {
        return new WP_Error('invalid_quiz_data', 'Failed to parse quiz data from API response', array('status' => 500));
    }
    
    return $quiz_data;
}

/**
 * Shortcode handler with inline onclick handlers
 */
function gemini_quiz_shortcode_handler($atts) {
    static $instance_count = 0;
    $instance_count++;
    $unique_id = 'gemini_quiz_' . $instance_count;
    
    global $post;
    $post_id = $post ? $post->ID : 0;
    
    // Get content title for display
    $content_title = 'this page';
    if ($post && $post->post_title) {
        $content_title = $post->post_title;
    }
    
    // Enqueue styles and scripts
    gemini_quiz_enqueue_assets();
    
    // Return complete HTML with inline onclick handlers
    $output = '
    <div id="' . esc_attr($unique_id) . '" class="gemini-quiz-container" data-post-id="' . esc_attr($post_id) . '" style="margin: 20px 0; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif; max-width: 100%; box-sizing: border-box;">
        <div class="quiz-card" style="background: #ffffff; border: 2px solid #de200b; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.15); overflow: hidden;">
            <div class="quiz-header" style="background: linear-gradient(135deg, #de200b 0%, #b91c0c 100%); color: white; padding: 24px 20px; border-radius: 8px; text-align: center; margin: -20px -20px 24px -20px;">
                <h2 style="margin: 0; font-size: clamp(20px, 4vw, 28px); font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">🎯 Quiz Generator</h2>
                <p style="margin: 12px 0 0 0; opacity: 0.95; font-size: clamp(14px, 3vw, 16px);">Test your knowledge of ' . esc_html($content_title) . '</p>
            </div>
            <div style="text-align: center; padding: 0 10px;">
                <p style="margin: 20px 0; font-size: clamp(15px, 3.5vw, 18px); color: #333; line-height: 1.6;">
                    Ready to test your understanding? I\'ll create a personalized quiz based on the content of this page.
                </p>
                <button onclick="startQuiz_' . esc_js($unique_id) . '()" style="background: linear-gradient(135deg, #de200b 0%, #b91c0c 100%); color: white; border: none; padding: 16px 32px; border-radius: 8px; cursor: pointer; font-size: clamp(16px, 3.5vw, 18px); font-weight: 600; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.3); transition: all 0.3s ease; min-height: 48px; min-width: 120px;">
                    Generate Quiz
                </button>
            </div>
        </div>
    </div>
    
    <script>
    // Global quiz state for instance ' . esc_js($unique_id) . '
    window.quizState_' . esc_js($unique_id) . ' = {
        state: "config",
        questions: [],
        currentQuestion: 0,
        score: 0,
        selectedAnswer: null,
        containerId: "' . esc_js($unique_id) . '",
        postId: ' . $post_id . '
    };
    
    // Global function for starting quiz
    window.startQuiz_' . esc_js($unique_id) . ' = function() {
        console.log("Start quiz clicked for ' . esc_js($unique_id) . '");
        var container = document.getElementById("' . esc_js($unique_id) . '");
        var state = window.quizState_' . esc_js($unique_id) . ';
        
        // Show loading
        container.innerHTML = `
            <div class="quiz-card" style="background: #ffffff; border: 2px solid #de200b; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.15); overflow: hidden;">
                <div class="quiz-header" style="background: linear-gradient(135deg, #de200b 0%, #b91c0c 100%); color: white; padding: 24px 20px; border-radius: 8px; text-align: center; margin: -20px -20px 24px -20px;">
                    <h2 style="margin: 0; font-size: clamp(20px, 4vw, 28px); font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">🤖 Creating Your Quiz...</h2>
                </div>
                <div style="text-align: center; padding: 40px 20px;">
                    <div style="font-size: clamp(16px, 4vw, 20px); margin-bottom: 20px; color: #333; font-weight: 600;">Analyzing content...</div>
                    <div style="width: 100%; background: #f0f0f0; height: 12px; border-radius: 6px; overflow: hidden; margin: 20px 0;">
                        <div style="width: 60%; height: 100%; background: linear-gradient(90deg, #de200b, #b91c0c); animation: pulse 2s infinite; border-radius: 6px;"></div>
                    </div>
                    <div style="font-size: clamp(14px, 3vw, 16px); color: #666; margin-top: 20px;">This may take a few moments...</div>
                </div>
            </div>
        `;
        
        // Get page content
        var content = getPageContent_' . esc_js($unique_id) . '();
        console.log("Content length:", content.length);
        
        // Call API
        fetch("/wp-json/quiz-generator/v1/generate", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                article: content,
                postId: state.postId
            })
        })
        .then(function(response) {
            return response.json();
        })
        .then(function(data) {
            console.log("API response:", data);
            if (data.quiz && data.quiz.length > 0) {
                state.questions = data.quiz;
                state.state = "playing";
                state.currentQuestion = 0;
                state.score = 0;
                state.selectedAnswer = null;
                showQuestion_' . esc_js($unique_id) . '();
            } else {
                showError_' . esc_js($unique_id) . '("No quiz data received from API.");
            }
        })
        .catch(function(error) {
            console.error("Quiz generation failed:", error);
            showError_' . esc_js($unique_id) . '("Failed to generate quiz. Please try again.");
        });
    };
    
    // Function to get page content
    window.getPageContent_' . esc_js($unique_id) . ' = function() {
        var selectors = [".entry-content", ".post-content", ".page-content", "main", "article"];
        
        for (var i = 0; i < selectors.length; i++) {
            var element = document.querySelector(selectors[i]);
            if (element) {
                var clone = element.cloneNode(true);
                var unwanted = clone.querySelectorAll(".gemini-quiz-container, script, style, nav, .sidebar, .comments");
                for (var j = 0; j < unwanted.length; j++) {
                    unwanted[j].remove();
                }
                
                var text = clone.innerText.trim();
                if (text.length > 100) {
                    return text;
                }
            }
        }
        
        return document.body.innerText.trim();
    };
    
    // Function to show question
    window.showQuestion_' . esc_js($unique_id) . ' = function() {
        var container = document.getElementById("' . esc_js($unique_id) . '");
        var state = window.quizState_' . esc_js($unique_id) . ';
        var question = state.questions[state.currentQuestion];
        var progress = ((state.currentQuestion + 1) / state.questions.length) * 100;
        
        var optionsHtml = "";
        question.options.forEach(function(option, index) {
            var optionStyle = "display: block; width: 100%; padding: 16px 20px; margin: 12px 0; border: 2px solid #e0e0e0; border-radius: 8px; background: #ffffff; cursor: pointer; text-align: left; font-size: clamp(14px, 3.5vw, 16px); line-height: 1.5; color: #333333 !important; font-weight: 500; transition: all 0.3s ease; min-height: 56px; box-sizing: border-box;";
            var disabled = "";
            var hoverEvents = "";
            
            if (state.selectedAnswer !== null) {
                disabled = "disabled";
                if (index === question.correctAnswer) {
                    optionStyle = "display: block; width: 100%; padding: 16px 20px; margin: 12px 0; border: 2px solid #28a745; border-radius: 8px; background: #d4edda; cursor: default; text-align: left; font-size: clamp(14px, 3.5vw, 16px); line-height: 1.5; color: #155724 !important; font-weight: 600; min-height: 56px; box-sizing: border-box;";
                } else if (index === state.selectedAnswer) {
                    optionStyle = "display: block; width: 100%; padding: 16px 20px; margin: 12px 0; border: 2px solid #dc3545; border-radius: 8px; background: #f8d7da; cursor: default; text-align: left; font-size: clamp(14px, 3.5vw, 16px); line-height: 1.5; color: #721c24 !important; font-weight: 600; min-height: 56px; box-sizing: border-box;";
                }
            } else {
                hoverEvents = "onmouseover=\\"this.style.borderColor=\'#de200b\'; this.style.backgroundColor=\'#fef7f7\';\\" onmouseout=\\"this.style.borderColor=\'#e0e0e0\'; this.style.backgroundColor=\'#ffffff\';\\"";
            }
            
            optionsHtml += `
                <button onclick="selectAnswer_' . esc_js($unique_id) . '(${index})" ${disabled} ${hoverEvents} style="${optionStyle}">
                    ${option}
                </button>
            `;
        });
        
        var explanationHtml = "";
        var nextButtonHtml = "";
        
        if (state.selectedAnswer !== null) {
            explanationHtml = `
                <div style="margin: 24px 0; padding: 20px; background: #fef7f7; border-radius: 8px; border-left: 4px solid #de200b;">
                    <strong style="color: #de200b; font-size: clamp(15px, 3.5vw, 17px);">Explanation:</strong> 
                    <span style="color: #333; font-size: clamp(14px, 3.5vw, 16px); line-height: 1.6;">${question.explanation}</span>
                </div>
            `;
            
            var nextText = state.currentQuestion < state.questions.length - 1 ? "Next Question" : "View Results";
            nextButtonHtml = `
                <div style="text-align: center; margin-top: 24px;">
                    <button onclick="nextQuestion_' . esc_js($unique_id) . '()" style="background: linear-gradient(135deg, #de200b 0%, #b91c0c 100%); color: white; border: none; padding: 16px 32px; border-radius: 8px; cursor: pointer; font-size: clamp(16px, 3.5vw, 18px); font-weight: 600; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.3); transition: all 0.3s ease; min-height: 48px; min-width: 120px;">
                        ${nextText}
                    </button>
                </div>
            `;
        }
        
        container.innerHTML = `
            <div class="quiz-card" style="background: #ffffff; border: 2px solid #de200b; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.15); overflow: hidden;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                    <span style="font-weight: 700; color: #de200b; font-size: clamp(14px, 3.5vw, 16px);">Question ${state.currentQuestion + 1} of ${state.questions.length}</span>
                    <span style="color: #666; font-size: clamp(14px, 3.5vw, 16px); font-weight: 600;">Score: ${state.score}/${state.currentQuestion}</span>
                </div>
                <div style="background: #f0f0f0; height: 12px; border-radius: 6px; margin: 20px 0; overflow: hidden;">
                    <div style="background: linear-gradient(90deg, #de200b, #b91c0c); height: 100%; width: ${progress}%; transition: width 0.5s ease; border-radius: 6px;"></div>
                </div>
                <h3 style="margin: 24px 0 20px 0; font-size: clamp(18px, 4.5vw, 24px); line-height: 1.4; color: #333; font-weight: 700;">${question.question}</h3>
                <div style="margin: 20px 0;">
                    ${optionsHtml}
                </div>
                ${explanationHtml}
                ${nextButtonHtml}
            </div>
        `;
    };
    
    // Function to select answer
    window.selectAnswer_' . esc_js($unique_id) . ' = function(answerIndex) {
        var state = window.quizState_' . esc_js($unique_id) . ';
        if (state.selectedAnswer !== null) return;
        
        state.selectedAnswer = answerIndex;
        if (answerIndex === state.questions[state.currentQuestion].correctAnswer) {
            state.score++;
        }
        showQuestion_' . esc_js($unique_id) . '();
    };
    
    // Function to go to next question
    window.nextQuestion_' . esc_js($unique_id) . ' = function() {
        var state = window.quizState_' . esc_js($unique_id) . ';
        if (state.currentQuestion < state.questions.length - 1) {
            state.currentQuestion++;
            state.selectedAnswer = null;
            showQuestion_' . esc_js($unique_id) . '();
        } else {
            state.state = "results";
            showResults_' . esc_js($unique_id) . '();
        }
    };
    
    // Function to show results
    window.showResults_' . esc_js($unique_id) . ' = function() {
        var container = document.getElementById("' . esc_js($unique_id) . '");
        var state = window.quizState_' . esc_js($unique_id) . ';
        var percentage = Math.round((state.score / state.questions.length) * 100);
        var message = "";
        var emoji = "";
        
        if (percentage >= 80) {
            message = "Excellent! You really know your stuff!";
            emoji = "🎉";
        } else if (percentage >= 60) {
            message = "Good job! You have a solid understanding.";
            emoji = "👍";
        } else if (percentage >= 40) {
            message = "Not bad! Consider reviewing the material.";
            emoji = "📚";
        } else {
            message = "Keep learning! Practice makes perfect.";
            emoji = "💪";
        }
        
        container.innerHTML = `
            <div class="quiz-card" style="background: #ffffff; border: 2px solid #de200b; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.15); overflow: hidden;">
                <div style="text-align: center; padding: 32px 20px;">
                    <div style="font-size: clamp(40px, 8vw, 60px); margin-bottom: 20px;">${emoji}</div>
                    <h2 style="margin: 0 0 20px 0; color: #de200b; font-size: clamp(24px, 5vw, 32px); font-weight: 700;">Quiz Complete!</h2>
                    <div style="font-size: clamp(36px, 8vw, 56px); font-weight: 800; color: #de200b; margin: 20px 0; text-shadow: 0 2px 4px rgba(222, 32, 11, 0.2);">${state.score}/${state.questions.length}</div>
                    <div style="font-size: clamp(20px, 4vw, 24px); margin: 16px 0; color: #666; font-weight: 600;">${percentage}% Correct</div>
                    <div style="font-size: clamp(16px, 3.5vw, 18px); margin: 24px 0; color: #333; line-height: 1.6; font-weight: 500;">${message}</div>
                    <button onclick="resetQuiz_' . esc_js($unique_id) . '()" style="background: linear-gradient(135deg, #de200b 0%, #b91c0c 100%); color: white; border: none; padding: 16px 32px; border-radius: 8px; cursor: pointer; font-size: clamp(16px, 3.5vw, 18px); font-weight: 600; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.3); transition: all 0.3s ease; min-height: 48px; min-width: 140px; margin-top: 20px;">
                        Take Quiz Again
                    </button>
                </div>
            </div>
        `;
    };
    
    // Function to show error
    window.showError_' . esc_js($unique_id) . ' = function(message) {
        var container = document.getElementById("' . esc_js($unique_id) . '");
        container.innerHTML = `
            <div class="quiz-card" style="background: #ffffff; border: 2px solid #de200b; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.15); overflow: hidden;">
                <div style="text-align: center; padding: 40px 20px; color: #dc3545;">
                    <div style="font-size: clamp(40px, 8vw, 60px); margin-bottom: 20px;">⚠️</div>
                    <h3 style="margin: 0 0 20px 0; font-size: clamp(20px, 4vw, 24px); color: #dc3545;">Quiz Generation Failed</h3>
                    <p style="margin: 0 0 24px 0; font-size: clamp(16px, 3.5vw, 18px); line-height: 1.6;">${message}</p>
                    <button onclick="resetQuiz_' . esc_js($unique_id) . '()" style="background: linear-gradient(135deg, #de200b 0%, #b91c0c 100%); color: white; border: none; padding: 16px 32px; border-radius: 8px; cursor: pointer; font-size: clamp(16px, 3.5vw, 18px); font-weight: 600; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.3); transition: all 0.3s ease; min-height: 48px; min-width: 120px;">
                        Try Again
                    </button>
                </div>
            </div>
        `;
    };
    
    // Function to reset quiz
    window.resetQuiz_' . esc_js($unique_id) . ' = function() {
        var container = document.getElementById("' . esc_js($unique_id) . '");
        var state = window.quizState_' . esc_js($unique_id) . ';
        
        state.state = "config";
        state.questions = [];
        state.currentQuestion = 0;
        state.score = 0;
        state.selectedAnswer = null;
        
        container.innerHTML = `
            <div class="quiz-card" style="background: #ffffff; border: 2px solid #de200b; border-radius: 12px; padding: 20px; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.15); overflow: hidden;">
                <div class="quiz-header" style="background: linear-gradient(135deg, #de200b 0%, #b91c0c 100%); color: white; padding: 24px 20px; border-radius: 8px; text-align: center; margin: -20px -20px 24px -20px;">
                    <h2 style="margin: 0; font-size: clamp(20px, 4vw, 28px); font-weight: 700; text-shadow: 0 2px 4px rgba(0,0,0,0.3);">🎯 Quiz Generator</h2>
                    <p style="margin: 12px 0 0 0; opacity: 0.95; font-size: clamp(14px, 3vw, 16px);">Test your knowledge of ' . esc_html($content_title) . '</p>
                </div>
                <div style="text-align: center; padding: 0 10px;">
                    <p style="margin: 20px 0; font-size: clamp(15px, 3.5vw, 18px); color: #333; line-height: 1.6;">
                        Ready to test your understanding? I\'ll create a personalized quiz based on the content of this page.
                    </p>
                    <button onclick="startQuiz_' . esc_js($unique_id) . '()" style="background: linear-gradient(135deg, #de200b 0%, #b91c0c 100%); color: white; border: none; padding: 16px 32px; border-radius: 8px; cursor: pointer; font-size: clamp(16px, 3.5vw, 18px); font-weight: 600; box-shadow: 0 4px 12px rgba(222, 32, 11, 0.3); transition: all 0.3s ease; min-height: 48px; min-width: 120px;">
                        Generate Quiz
                    </button>
                </div>
            </div>
        `;
    };
    
    console.log("Quiz initialized successfully for ' . esc_js($unique_id) . '");
    </script>';
    
    return $output;
}

add_shortcode('gemini_quiz', 'gemini_quiz_shortcode_handler');

/**
 * Enqueue enhanced styles for mobile and theme compatibility
 */
function gemini_quiz_enqueue_assets() {
    static $assets_enqueued = false;
    
    if ($assets_enqueued) {
        return;
    }
    
    $assets_enqueued = true;
    
    // Add enhanced CSS with mobile-first approach
    add_action('wp_head', function() {
        echo '<style>
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* Mobile-first responsive design */
        .gemini-quiz-container {
            max-width: 100% !important;
            overflow-x: hidden !important;
        }
        
        .quiz-card {
            max-width: 100% !important;
            box-sizing: border-box !important;
        }
        
        /* Button hover effects */
        .quiz-button:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 6px 16px rgba(222, 32, 11, 0.4) !important;
        }
        
        .quiz-button:active {
            transform: translateY(0) !important;
        }
        
        /* Responsive text sizing */
        @media (max-width: 768px) {
            .gemini-quiz-container {
                margin: 15px 0 !important;
            }
            
            .quiz-card {
                padding: 16px !important;
                border-radius: 8px !important;
            }
            
            .quiz-header {
                padding: 20px 16px !important;
                margin: -16px -16px 20px -16px !important;
            }
        }
        
        @media (max-width: 480px) {
            .quiz-card {
                padding: 12px !important;
            }
            
            .quiz-header {
                padding: 16px 12px !important;
                margin: -12px -12px 16px -12px !important;
            }
        }
        
        /* Ensure text is always visible */
        .gemini-quiz-container * {
            text-decoration: none !important;
        }
        
        .gemini-quiz-container button {
            color: white !important;
        }
        
        /* High contrast for accessibility */
        @media (prefers-contrast: high) {
            .quiz-option {
                border-width: 3px !important;
            }
        }
        </style>';
    });
}

/**
 * Add admin menu for plugin settings
 */
add_action('admin_menu', 'gemini_quiz_admin_menu');

function gemini_quiz_admin_menu() {
    add_options_page(
        'Gemini Quiz Generator Settings',
        'Gemini Quiz',
        'manage_options',
        'gemini-quiz-settings',
        'gemini_quiz_settings_page'
    );
}

/**
 * Settings page
 */
function gemini_quiz_settings_page() {
    if (isset($_POST['submit'])) {
        check_admin_referer('gemini_quiz_settings');
        $api_key = sanitize_text_field($_POST['gemini_api_key']);
        update_option('gemini_api_key', $api_key);
        echo '<div class="notice notice-success"><p>Settings saved!</p></div>';
    }
    
    $api_key = get_option('gemini_api_key', '');
    $config_key_exists = defined('GEMINI_API_KEY');
    ?>
    <div class="wrap">
        <h1>Gemini Quiz Generator Settings</h1>
        
        <?php if ($config_key_exists): ?>
            <div class="notice notice-info">
                <p><strong>API Key Status:</strong> ✅ Using API key from wp-config.php</p>
            </div>
        <?php endif; ?>
        
        <form method="post" action="">
            <?php wp_nonce_field('gemini_quiz_settings'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Gemini API Key</th>
                    <td>
                        <input type="text" name="gemini_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" <?php echo $config_key_exists ? 'disabled' : ''; ?> />
                        <p class="description">
                            <?php if ($config_key_exists): ?>
                                API key is configured in wp-config.php.
                            <?php else: ?>
                                Enter your Google Gemini API key from <a href="https://aistudio.google.com/app/apikey" target="_blank">Google AI Studio</a>.
                            <?php endif; ?>
                        </p>
                    </td>
                </tr>
            </table>
            <?php if (!$config_key_exists): ?>
                <?php submit_button(); ?>
            <?php endif; ?>
        </form>
        
        <div class="card">
            <h2>Usage</h2>
            <p>Add the shortcode <code>[gemini_quiz]</code> to any page or post where you want the quiz to appear.</p>
            
            <h3>Theme Integration</h3>
            <p>The quiz is designed to match your site's theme color (#de200b) and is fully mobile-responsive.</p>
            
            <h3>Status Check</h3>
            <ul>
                <li>Plugin Version: <?php echo GEMINI_QUIZ_VERSION; ?></li>
                <li>WordPress Version: <?php echo get_bloginfo('version'); ?></li>
                <li>PHP Version: <?php echo PHP_VERSION; ?></li>
                <li>API Key: <?php echo $config_key_exists || !empty($api_key) ? '✅ Configured' : '❌ Not configured'; ?></li>
                <li>Theme Color: #de200b ✅</li>
                <li>Mobile Responsive: ✅</li>
            </ul>
        </div>
    </div>
    <?php
}

/**
 * Plugin activation hook
 */
register_activation_hook(__FILE__, 'gemini_quiz_activate');

function gemini_quiz_activate() {
    flush_rewrite_rules();
}

/**
 * Plugin deactivation hook
 */
register_deactivation_hook(__FILE__, 'gemini_quiz_deactivate');

function gemini_quiz_deactivate() {
    flush_rewrite_rules();
}